import React from 'react';


import {BrowserRouter as Router,Route,Switch,Link} from 'react-router-dom';
import First from './First';
import Second from './Second';
import Third from './Third';
function App() {
  return (
    <div >
      <Router>
        <Route path="/second" component={Second}/>
        <Route path="/first" render={(props)=><First {...props}></First>}/>
        <Route path="/third" component={Third}/>
      </Router>
      <a href="/first">first</a>
    </div>
  );
}

export default App;
