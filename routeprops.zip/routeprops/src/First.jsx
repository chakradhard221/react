import React from 'react';
import Redirect from 'react-router-dom'
 import { useState } from 'react';
export default function First(props){
    console.log(props);
    props.history.push('/third')
    const [password, setPassword] = useState('');

    return(
        <div>
            <input type="text" placeholder="password" onChange={this.chnageHandler}></input>
            <h2>FirstComponent</h2>


        </div>
    )
 
}
