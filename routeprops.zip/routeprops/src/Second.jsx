import React from 'react';
export default function Second(props){
    return(
        <div>
            <h3>Second</h3>
        </div>
    )
}