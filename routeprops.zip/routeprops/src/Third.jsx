import React from 'react'

export default function Third(){

    alert("..data..")
    return(
        <div>
            Dotgot
        </div>
    )
}