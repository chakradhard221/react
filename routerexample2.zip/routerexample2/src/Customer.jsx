import React from "react"
import Home from "./Home"
import './App.css';
// import {BrowserRouter as Router,Switch,Route} from "react-router-dom"
import axios from 'axios';
export default class Customer extends React.Component{
    
    constructor(){
        super()
        this.state={
            "userName":"",
            "password":""
        }
    }
changeHandler=event=>{
    console.log(event.target.value)
// alert(event.target.value)
this.setState({
    [event.target.name]:event.target.value
})
}

submitHandler=event=>{
    event.preventDefault()
console.log("..goingToStore...."+this.state)

}
render(){
    return(
            <div className="field">
              <h3  className="header">CustomerLogin</h3>
            <form onSubmit={this.submitHandler}>
            <div className="field">
                <input type="text" placeholder="userName" name="userName"onChange={this.changeHandler}/><br/></div>
                <div className="formInput">
               <input type="text" placeholder="password" name="password"onChange={this.changeHandler}/><br/></div>
               <div className="formInput">
                <button type="submit">Submit</button><br/></div>
                <a href="/customer">Login</a> <br/>
                <a href="/signUp">Register</a>
            </form>
            </div>
    )
        }
}