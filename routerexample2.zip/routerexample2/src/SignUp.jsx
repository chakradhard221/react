
import React, { Component } from 'react'
import './App.css';
import axios from 'axios';
export default class SignUp extends React.Component {

    constructor() {
        super()
        this.state = {
            "name": "",
            "mobile": "",
            "area": ""
        }
    }
    changeHandler = event => {
        alert("cliked.." + event.target.value)
        // event.preventDefault();
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    submitHandlerRequest = event => {
        event.preventDefault()

        console.log("..goingToStore...." + this.state)
        axios.post('http://localhost:5002/get', this.state).then(res => {
            console.log(res)
        }).catch(err => {
            console.log(err)
        })
    }
    render() {
        return (
            <div>
                <h2 className="header">Registration form</h2>
                <div style={{ "marginTop": "-20px" }} >
                    <form onSubmit={this.submitHandlerRequest}>
                        <div className="field">
                            <input className="formInput" type="text" name="name" placeholder="Enter your name" onChange={this.changeHandler} /><br />
                        </div>
                        <div className="field">
                            <input className="formInput" type="text" name="mobile" placeholder="Enter Your MobileNumber" onChange={this.changeHandler}></input><br />
                        </div>
                        <div className="field">
                            <input className="formInput" name="area" placeholder="Enter your Area" onChange={this.changeHandler} /><br />
                        </div>
                        <div className="field">
                            <button type="submit" className="button" >Submit</button><br /> </div>
                        <div className="field">
                            <button type="reset" className="button" >Reset</button><br /> </div>
                    </form>
                    <div className="field2">
                        <a href="/">Home</a>
                    </div>
                </div>
            </div>
        )
    }
} 