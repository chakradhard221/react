
import React from "react"
export default function Home(){






    
    return(
        <div>
            <h2>
                <a href="/customer">CustomerLogin</a>
            </h2>
        </div>
    )
}