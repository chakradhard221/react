import React, { Component } from 'react'




const NamesList = ({ names }) => {
    return (
        < div >
            <h2>RestServiceComponent</h2>
            {
                // names={this.props.data}
                names.map((name) => console.log("...asdf..." + name))
            }
        </div >
    )


}
export default NamesList