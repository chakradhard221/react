import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';
// import RestService from './RestService'
import NamesList from './NamesList'
export default class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isLoaded: false,
      names: []
    }
  }


  componentDidMount() {
    fetch('http://localhost:5002/list').then(res => res.json()).then((data) => {
      this.setState({
        isLoaded: true,
        items: data
      })
    }).catch(console.log)
  }
  render() {

    var { isLoaded, items } = this.state

    if (!isLoaded) {
      return <h2>Loading.....</h2>
    }
    else {
      return (
        <div>
          <h2>Data  loaded</h2>
          <ol>
            {
              items.map(itemName => (
                <li>
                  itemName
                </li>
              ))
            }
          </ol>
         </div>
      )
    }
  }
}
