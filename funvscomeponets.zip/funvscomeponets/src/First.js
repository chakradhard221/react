import React ,{Component} from 'react';
import Second from './Second';
// import Second from './Second'

export default class First extends  React.Component{


render(){
    return <Second></Second>
}


}