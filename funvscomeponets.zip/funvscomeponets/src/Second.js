import React, { useState } from 'react'
const Second=()=>{

    const [password,setPassword]=useState('')
    const handleSubmit=e=>{
     e.preventDefault();
     console.log(password)

    }
    return (
<form onSubmit={handleSubmit}>
<input type="text" name="userName" value={password} placeholder="name" onChange={e=>setPassword(e.target.value)}></input>
<br></br>
<button type="submit">Submit</button>
</form>
    );
}
export default Second;