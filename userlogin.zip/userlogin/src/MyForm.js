import React, { Component } from "react";

export default class MyForm extends React.Component{


    constructor(){
        super();
        this.handleSubmit=this.handleSubmit.bind(this);
    }


    handleSubmit(event){
        event.preventDefault();
      
        const data=new FormData(event.target)
        console.log("...data..."+data.keys());

        for(let key of data.keys()){
            console.log("..keys..."+key)
           console.log("...data..."+data.get(key))
        }

        fetch('http://localhost:8297/hh',{
            method:'POST',
            body:data
        })
    }




    render(){

        return(

            <form onSubmit={this.handleSubmit}>
                <label htmlFor="username">uSERNAME</label>
                <input id="username" name="username" type="text"></input><br></br>
                <button>SendData!</button>
            </form>

        );
    }
}