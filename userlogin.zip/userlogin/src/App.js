import React from 'react';
import MyForm from './MyForm'
import './App.css';

function App() {
  return (
    <MyForm></MyForm>
  );
}

export default App;
