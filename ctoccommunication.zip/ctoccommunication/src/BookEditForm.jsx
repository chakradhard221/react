import React, { useState } from 'react'
import BookTitle from './BookTitle'
export default function BookEditForm(props) {
  const [title, setTitle] = useState(props.book.title)
  function handleTitleChange(evt) {
      alert(evt)
    setTitle(evt.target.value)
    console.log(evt.target.value)
  }
  return (
    <form>
      <BookTitle onTitleChange={handleTitleChange} title={title} />
    </form>
  )
}