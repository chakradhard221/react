import React, { Component } from 'react';

export default function Book(props) {

    return (
        <div>
           
                <h2>{props.title}</h2>
                <div>{props.author}</div>
            
        </div>
    );

}