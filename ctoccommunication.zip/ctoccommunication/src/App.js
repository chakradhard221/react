import React from 'react';
import logo from './logo.svg';
import './App.css';
import BookList from './BookList';
import BookEditForm from './BookEditForm'
import BookTitle from './BookTitle';

function App() {
  return (
    <div className="App">
       {/* <BookList></BookList> */}
       {/* <BookEditForm></BookEditForm> */}
       <BookTitle></BookTitle>
    </div>
  );
}

export default App;
