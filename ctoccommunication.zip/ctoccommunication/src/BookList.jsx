import React,{Component, useLayoutEffect} from 'react'
import Book from './Book'

export default class BookList extends React.Component{
    
    render(){
        const list=[
            {title:'you can win',author:'shivakhera'},
            // {title:'Fragamaticprogrammer', author:'anderson'}
        ]
        return(
            <div>
               <ol>
               {list.map((book,i)=><Book title={book.title} author={book.author}/>)}
               </ol>
            </div>
        )
    }
}