import React,{Component} from 'react'
export default class Home extends React.Component{

    render(){
       return(
           <div>
               <h2>HomeComp</h2>
           </div>
       )
    }

}