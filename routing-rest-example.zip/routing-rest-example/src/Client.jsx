import React, { Component } from 'react'
import axios from 'axios'
export default class Client extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            name: '',
            phone: ''
        }

    }

    submitHandler = e => {
        e.preventDefault();
        console.log("...statedStttled...." + this.state.phone)
        axios.post('http://localhost:5002/get',this.state).then(res=>{
            console.log(res.json())
        }).catch(err=>{
            console.log("..err.."+err)
        })
    }

    handleChange=e=>{
        console.log("stateGetchnaged.....")
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    clickAction=e=>{
        axios.get("http://localhost:5002/list").then(res=>console.log(res)).catch(err=>console.log(err))
    }
    render() {
        return (
            <div>
                <h2>ClientRegistration...</h2>
                <form onSubmit={this.submitHandler}>
                    <input type='text' name='name' placeholder='Enter Your Name' value={this.state.name} onChange={this.handleChange}></input>
                    <input type='text' name='phone' placeholder='Enter Yout Mobile' value={this.state.phone} onChange={this.handleChange}></input>
                    <button type="submit">Submit</button>
                </form>
                <button onClick={this.clickAction}>GetData</button>
            </div>
        )
    }
}