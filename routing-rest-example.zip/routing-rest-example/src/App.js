import React from 'react';
import './App.css';
import Home from './Home'
import Client from './Client';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/" exact component={Home}></Route>
          <Route path="/client" component={Client}></Route>
          <a href="/client">client</a>
        </Switch>
        <a href='/client'>clientRegistration</a>
      </div>
    </Router>
  );
}

export default App;
