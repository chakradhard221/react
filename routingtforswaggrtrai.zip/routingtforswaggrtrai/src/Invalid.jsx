import React ,{Component} from 'react'


export default class Invalid extends React.Component{
    render(){
        return(
            <div>
                <h2>
                    am from Invalid
                </h2>
            </div>
        )
    }
}