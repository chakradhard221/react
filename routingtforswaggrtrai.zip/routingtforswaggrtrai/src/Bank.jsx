
import React, { Component } from 'react';
// import valid, { Valid }  from './Valid'
// import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import { useHistory } from "react-router-dom";
 export default class Bank extends React.Component {
    constructor() {
    super()
        this.state={
            "name":'',
            "password":''
        }
    }
    changeHandler=event=>{
        event.preventDefault()

        this.setState({
            [event.target.name]:event.target.value
        })
        }
        submitHandler=event=>{
            event.preventDefault()
            console.log(this.state)
           if(this.state.password=="mff"){
                const hist=useHistory();
                hist.push("/file")
           
           }
        }
    render() {
        return (
            <div>
                <h2>
                    LoginForm
            </h2>
                <form onSubmit={this.submitHandler}>
                    <input type="text" placeholder="EnterUserName" name="name" value={this.state.name} onChange={this.changeHandler} ></input>
                    <input type="text" placeholder="EnterPassword" name="password" value={this.state.password} onChange={this.changeHandler} ></input>                   
                    <button type="submit">submit</button>
                </form>


            </div>

        )
    }


}