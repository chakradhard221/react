import React ,{Component} from "react"
export class Valid extends React.Component{
    render(){
        return(
            <div>
                <h2>am from valid</h2>
            </div>
        )
    }
}