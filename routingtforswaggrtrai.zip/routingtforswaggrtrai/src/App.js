import React from 'react';

import './App.css';
// import { Bank } from './Bank';

import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom'
import { Valid } from './Valid';
import Invalid from './Invalid';
import Bank from './Bank';
function App() {

  return (
    <div>
      {/* <Valid></Valid> */}
      {/* <Invalid></Invalid> */}
{/* <Bank></Bank> */}
      <Router>
      <Route path="bank" Component={Bank}></Route>
        <Route path="file" Component={Valid}></Route>
        <Route path="infile" Component={Invalid}></Route>
      </Router>
      <a href="bank">Valid</a>
      <a href="infile">Valid</a>
    </div>

    // <Router>
    //   <div className="App">
    //     <Route path="/form" component={Bank}></Route>
    //     <a href="/form">client</a>
    //     {/* {<Bank></Bank>} */}
    //   </div>
    // </Router>

  );
}

export default App;
