import React from 'react'

const Button=(props)=>{
    let ages=props.age?props.age:'NA'

    if(props.children){
        return (<div>{props.children},{ages}</div>)
    }
    else{
        return (<div>InvalidEntry</div>)
    }

}
export default Button;
