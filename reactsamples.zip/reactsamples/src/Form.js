import React from 'react';
import Component from 'react'


export default class Form extends React.Component {

    state = {
        "userName": "",
        "password": "",
        "email": "",
        "phone": ""
    }


    change = e => {
        this.setState({
            [e.target.userName]: e.target.value
        })
    };

    onSubmit = (e) => {
        e.preventDefault();
        console.log(this.state)
    }
    render() {
        return (
            <form>
                <input name="userName" placeholder="userName" value={this.state.userName} onChange={e => this.change(e)}></input>
                <br></br>
                <input name="password" placeholder="password" value={this.state.password} onChange={e => this.change(e)}></input>
                <br></br>
                <button onClick={(e) => this.onSubmit(e)}>Submit</button>
            </form>
        )
    }
}