import React from 'react';
import logo from './logo.svg';
import './App.css';
import Form from './Form'
import Button from './Button'

function App() {

  return (
  <div>
    <Button>killer</Button>
    <Button age="20">killer2</Button>
    <Button age="30">killer3</Button>
  </div>


  


  );

}

export default App;
