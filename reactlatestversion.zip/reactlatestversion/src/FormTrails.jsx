
import React,{Component} from 'react'
import axios from 'axios'

export default class FormTrails extends React.Component{
    constructor(){
       super()
        this.state={
            name:"",
            mobile:"",
            area:""
        }
    }
    submitHandler=event=>{
        event.preventDefault()
        console.log(this.state)
        axios.post("http://localhost:8885/post",this.state).then(res=>console.log(res))
    }
    changeHandler=event=>{
        event.preventDefault()
        this.setState({
       [event.target.name]:event.target.value
        })
    }
render(){
    return(
        <div>
            <h2>LoginFrom</h2>
            <form onSubmit={this.submitHandler}>
            <input type="text" name="name" id="name" placeholder="EnterYourName" onChange={this.changeHandler} />
           <input type="text" name='mobile' id="mobile" placeholder="Enter your Mobile" onChange={this.changeHandler}></input>
          <input type="text" name="area" id="area" placeholder="Area" onChange={this.changeHandler}/>
          <button type="submit">Submit</button>
        </form>
        </div>
    )
}
}