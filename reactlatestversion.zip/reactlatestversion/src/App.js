import React from 'react';
import logo from './logo.svg';
import './App.css';
import FormTrails from './FormTrails'
function App() {
  return (
    <div className="App">
     <FormTrails></FormTrails>
    </div>
  );
}

export default App;
