
import React from "react";
import Component from 'react';

export default class DropComponent extends React.Component{

render(){
    return "hello goodmorning hyderabad";
//     return(
// <div className='shopping-list'>
//     <h1>ShoppingListFor{this.props.name}</h1>
//         <ul>
//             <li>Instagram</li>
//             <li>Facebook</li>
//             <li>Whatsup</li>
//         </ul>
// </div>
//     )
}
}