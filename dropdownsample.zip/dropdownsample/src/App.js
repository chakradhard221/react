import React from 'react';
import logo from './logo.svg';
import './App.css';
import DropComponent from './drop'

function App() {
  return (
    <div className="App">
     <DropComponent></DropComponent>
    </div>
  );
}

export default App;
