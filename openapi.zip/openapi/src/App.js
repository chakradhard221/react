import React from 'react';
import './App.css';
import LoginPage from './LoginPage';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import Nav from './Nav'
import ApiInfo from './ApiInfo';
function App() {
  return (
 <div>
   <Router>
   <Switch>
     {/* <Route path='/' exact component={Nav}></Route> */}
     {/* <Route path='/login' exact component={LoginPage}></Route> */}
     <Route path="/" exact render={(props)=><LoginPage {...props}></LoginPage>}/>
     <Route path="/apin" exact component={ApiInfo}></Route>
     </Switch>
   </Router>
 </div>
  );
}

export default App;
