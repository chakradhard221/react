import React, { Component, useState } from 'react';
import { Redirect } from 'react-router-dom'
import { browserHistory } from 'react-router';
import ApiInfo from './ApiInfo';
import { BrowserRouter as Router, Route } from 'react-router-dom'

const LoginPage = (props) => {
    const [password, setPassword] = useState('')
    const handleSubmit = e => {
        e.preventDefault();
        console.log(password)
        if (password == 'Solitx$987') {
            alert("...true...")
            props.history.push('apin')
        }
        else {
            alert('Invalid password')
            props.history.push('/')
        }
    }
    return (
        <div className="devF">
            <form onSubmit={handleSubmit}>
                {/* <label className="labelF">USERNAME</label>  <br />
                    <input className="textF" name="username" type="text" placeholder="username" onChange={this.changeHandler}></input><br /> */}
                <label className="labelF">Api Key</label>  <br />
                <input className="textF" name="password" type="text" placeholder="apikey" onChange={e => setPassword(e.target.value)}></input><br />
                <button className="buttonF" type="submit">Submit</button>
            </form>
        </div>
    )
}


export default LoginPage;