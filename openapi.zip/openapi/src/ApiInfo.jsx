import React, { Component } from 'react';
import { RedocStandalone } from 'redoc';

export default class ApiInfo extends React.Component {
  render() {
    return (
      <div>
        {/* <redoc spec-url="https://test.mobilefirstfinance.com/demoswagger.json"></redoc> */}
        {/* <redoc spec-url="http://petstore.swagger.io/v2/swagger.json"></redoc> */}
        <RedocStandalone specUrl="http://78.46.98.168:8080/swagger.json"
          options={{ "hideDownloadButton": true }} />

        {/* <redoc spec-url="http://78.46.98.168:8080/swagger.json"></redoc>
        <script src="http://78.46.98.168:8080/util.js"> </script> */}
      </div>
    )
  }
}
