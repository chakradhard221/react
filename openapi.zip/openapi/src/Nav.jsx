import React, { Component } from 'react'
import './App.css'
import { Link } from 'react-router-dom'
// import flower from './images/flower.jpg'
// import logo from './logo'
class Nav extends React.Component {
    render() {
        return (
            <nav>
                <ul className="nav-link">
                    <Link to='/login'>
                    <li>
                    Login
                    </li>
                    </Link>
                    <Link to="/login">
                    <li>
                    ApiInfo
                    </li>
                    </Link>
                </ul>
            </nav>
        )
    }
}
export default Nav;