import  React, { useEffect,useState } from 'react';

export default function Shop (){

    // componentDidMount(){
    //     fetch("https://localhost:5002/list").then(res=>res.json()).then(data=>console.log(data));
    // }
    // useEffect(()=>{
    //     fetchItems();
    // });
    // const fetchItems=() =>{
    //    const data= fetch("https://localhost:5002/list");
    //    alert(data)
    //    console.log("data from Remote.."+JSON.stringify(data))
    // }
    return(
        <div>
            <h1>ShopNow</h1>
        </div>
    )
}