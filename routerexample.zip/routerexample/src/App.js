import React from 'react';

import './App.css';
import Nav from './Nav';
import Shop from './Shop';
// import {BrowserRouter as Router ,Switch,Route} from 're'
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom'
import About from './About';
function App() {
  return (
    <Router>
    <div>
     <Nav></Nav>
      <Switch>
     <Route path="/"  exact component={Home}></Route>
     <Route path="/shop" component={Shop}></Route>
     <Route path="/about" component={About}></Route>
     </Switch>
    </div>
    </Router>
  );
}


const Home=()=>(
  <div>
    <h1>HomePage</h1>
  </div>
)
export default App;
