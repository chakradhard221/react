import React from 'react';
export default function About(){

    return(
        <div>
            <h1>
                AboutUs
            </h1>
        </div>
    )
}