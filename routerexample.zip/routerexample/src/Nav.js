import React from 'react';
// import Links from 'react-router-dom'
import {Link} from 'react-router-dom'

 export default function Nav(){
     return(
         <nav>
             <h3>LOGO</h3>
             <ul className='nav-link'>
                 <Link to="/shop">
                 <li>Shop </li>
                 </Link>
                 <Link to="/about"><li>About</li></Link>
                 <Link to="/"><li>Home</li></Link>
             </ul>
         </nav>
     )
 }