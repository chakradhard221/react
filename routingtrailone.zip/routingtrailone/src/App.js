import React from 'react' 
import {BrowserRouter as Router,Route} from 'react-router-dom'
import Home from './Home';
import Bank from './Bank'
export default function App() {
  return (
    <div>
              <Router>
          {/* <Route path="/home" render={props=><Home {...props}></Home>}></Route> */}
          <Route path="/home" component={Home}></Route>
          <Route path="/bank" component={Bank}></Route>
      </Router>
      <a href="/home">Home</a>
    </div>
  );
}


