import React,{Component}from 'react';




export default class Home extends React.Component{

    // componentWillMount(){
    //     this.props.history.push('/bank')
    // }


    render(){
        return(
       <div>Hloo
<form action="/bank">
 <button type="submit">Submit</button>

</form>
           <a href="/bank">bank</a>
       </div>
        )
    }
}