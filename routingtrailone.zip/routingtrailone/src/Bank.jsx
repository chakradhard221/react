import React,{Component} from 'react';

export default class Bank extends React.Component{

    render(){
        return(
            <div>
                <h3>Hello bank</h3>
            </div>
        )
    }
}