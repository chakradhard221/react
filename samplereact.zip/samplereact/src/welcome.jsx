
import React from 'react';
export class Welcome extends React.Component{

render(){

return(
<html>
    <h2>UserLogin</h2>
    <form>
  <label>
    Name:
    <input type="text" name="name" />
  </label>
  <input type="submit" value="Submit" />
</form>
    
</html>


);


}


}