import React from 'react';

import FormOne from './formOne'

function App() {


 
  return (
    <div>
      <FormOne name='lisa'></FormOne>
    </div>
  );
}

export default App;
