import React, { Component } from 'react'
export default class FormOne extends React.Component {

    constructor() {
        super()
        this.state = {
            'username': '',
            'password': ''
        }
    }
    submitHandler = event => {

console.log(this.state)
    }
    changeHandler = event => {
        // event.target.name:this.state.usernamee
console.log(event)

        this.setState({
            [event.target.name]: event.target.value

        })
    }
    render() {
        return (
            <div>
                <h2>this long trail</h2>
                <h2>this.props</h2>
                <input type="text" name="username" placeholder="username" onChange={this.changeHandler} value={this.state.username}/><br></br>
                <input type="text" name="password" id="" placeholder="password" onChange={this.changeHandler}/><br></br>
                <input type="button" value="Submit" onClick={this.submitHandler}/>
            </div>
        );
    }
}