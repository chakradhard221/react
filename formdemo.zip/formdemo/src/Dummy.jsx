import  React ,{Component} from 'react';
export default class Dummty extends React.Component{
    render(){
        return(
            <div>
                <h3>
                    am from dummy 
                </h3>
            </div>
        )
    }
}