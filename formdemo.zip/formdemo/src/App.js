import React from 'react';
import { RedocStandalone } from 'redoc';
import { Redoc } from 'redoc';
import FormSam from './FormSam'
import {BrowserRouter as Router, Route } from 'react-router-dom'
import { swaggerfile } from './swaggerfile';
import swaggerfile2 from './swaggerfile2';
import Dummty from './Dummy';
function App() {
  return (
    <Router>
      <div>
        <Route path="/r" component={swaggerfile}></Route>
        <Route path="/f" component={swaggerfile2}></Route>
        <Route path="dum" component={Dummty}></Route>
      </div>
      <a href="r">file</a>
      <a href="f">file2</a>
    </Router>
    // <div>
    //   <h2>Login</h2>

    /* <redoc spec-url="url/to/your/spec"></redoc> */
    /* <RedocStandalone
      specUrl="http://petstore.swagger.io/v2/swagger.json"
      // specUrl="./../public/swagger.json"
      options={{
        nativeScrollbars: true,
        theme: { colors: { primary: { main: '#dd5522' } } },
      }}
    />
    <script 
    
    src="https://rebilly.github.io/ReDoc/releases/latest/redoc.min.js"
    // src="./../scripts/util.js"
    > </script> */


    /* <FormSam></FormSam> */


    // </div>
  );
}

export default App;
