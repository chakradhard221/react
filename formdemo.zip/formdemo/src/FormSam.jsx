import React,{Component} from 'react';
import { RedocStandalone } from 'redoc';
import { Redoc } from 'redoc';
export default class FormSam extends React.Component{
    constructor(){
       super() 
       this.state={
           'userName':'',
           'password':'',
           'rootUser':''
       }
    }

  
    submitHandler=event=>{
        event.preventDefault()
        console.log("onsubmitcalleddd....",this.state)
    }
    changeHandler=event=>{
        event.preventDefault()
        console.log([event.target.name]);
        console.log([event.target.value]);
        this.setState({
            [event.target.name]: event.target.value
        })
        console.log("state....."+this.state)
    }
    render(){
        return(
            <div>
            <h2>HelloAm FormSam</h2>
                <form onSubmit={this.submitHandler}>
                <input type="text" name="userName" placeholder="userName" onChange={this.changeHandler}/><br></br>
                <input type="text" name="password" placeholder="password" onChange={this.changeHandler}/><br></br>
                <input type="text" name="rootUser" placeholder="rootUser" onChange={this.changeHandler}/><br></br>
                <button type="submit">Submit</button>
                </form>
            </div>
        );
    }
}   