import React ,{Component} from 'react'
import { RedocStandalone } from 'redoc';
import { Redoc } from 'redoc';

export default class swaggerfile2 extends React.Component{
  nwe
render(){
    return(
        <div>
               {/* <redoc spec-url="url/to/your/spec"></redoc>  */}
     <RedocStandalone
      // specUrl="http://petstore.swagger.io/v2/swagger.json"
    specUrl="http://78.46.98.168:8080/swagger.json"
      // specUrl="http://localhost:3001/public/swagger.json"

     
      options={{
        // nativeScrollbars: true,
        headers:{"Access-Control-Allow-Origin":'*'},
        cors:true,
        theme: { colors: { primary: { main: '#dd5522' } } },
      }}
    />
    <script 
    
    // src="https://rebilly.github.io/ReDoc/releases/latest/redoc.min.js"
    src="http://78.46.98.168:8080/util.js"
    > </script> 
            </div>
    )
}
}