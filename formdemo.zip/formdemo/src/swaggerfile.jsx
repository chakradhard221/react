import React, { Component } from 'react';
import { RedocStandalone } from 'redoc';
import { Redoc } from 'redoc';
import { withRouter ,useHistory} from 'react-router-dom'
import { browserHistory } from 'react-router';
import { Redirect, Link } from 'react-router-dom'
export class swaggerfile extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      "name": ""
    }

  }
  submitHadler = event => {
    event.preventDefault();
    console.log("...event..." + event)
    console.log("...state..." + this.state.name)
    attributeCase(this.state.name);
  }
  changeHandler = event => {
    this.setState({
      [event.target.name]: event.target.value
    })
  }

  render() {
    return (
      <div>
        <form  action="/f">
          <input type="text" name="name" placeholder="EnterName" onChange={this.changeHandler} value={this.state.name} />
          <button type="submit">Submit</button>
        </form>
      </div>
    )
  }

 
}
function attributeCase(name){
  alert(name)
  let dummy='mff'

  // let history = useHistory()
    if(name==dummy){
      alert("..if....mff..");
      return <Redirect to="f" />
    }
    else{
      alert("...non..mff..");
      return <Link to='f'>getIn</Link>
    }
}