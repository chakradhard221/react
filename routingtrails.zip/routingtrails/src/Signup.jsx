import React,{Component} from 'react'
export default class Signup extends React.Component{

    render(){
        return(
            <div>
                <h2>
                    SignupModule
                </h2>
            </div>
        )
    }
}