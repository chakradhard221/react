import React, { Component } from 'react'
export default class Payment extends React.Component{
constructor(){
    super()

    this.state={
        firstName:'',
        lastName:'',
        mobile:'',
        country:''
    }
}

changeHandler=event=>{
    this.setState({
        [event.target.name]:event.target.value
    })
}
submitHandler=event=>{
    event.preventDefault()
    console.log(this.state)
}
    render(){
        return(
            <div>
                <h2>SignupModule</h2>
                <form onSubmit={this.submitHandler}>
            <input type="text" placeholder="FirstName" name="firstName" onChange={this.changeHandler}></input><br/>
            <input type="text" placeholder="LastName" name="lastName" onChange={this.changeHandler}></input><br/>
            <input type="text" placeholder="MobileNumber" name="mobile" onChange={this.changeHandler}></input><br/>
            <input type="text" placeholder="Country" name="country" onChange={this.changeHandler}></input><br/>
             <button type="submit">submit</button>
               </form>
            </div>
        )
    }
}