import React, { Component } from 'react';
// import logo from './logo.svg';
import flower from './images/flower.jpg'
import LoginComponent from './LoginComponent'
import Signup from './Signup'
import './App.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import Nav from './Nav'
import Payment from './Payment';
function App() {
  return (
    <div className="App">
      <Router>
        {/* <img src={flower} className="App-logo"></img> */}
    <Nav></Nav>
        <Switch>
          <Route path="/home" exact component={LoginComponent}/>
            <Route path="/pay" component={Payment}/>
        </Switch>
        {/* <Link to ="/home">

<button>Login</button>
</Link> */}
      </Router>




    </div>
  );
}

export default App;
