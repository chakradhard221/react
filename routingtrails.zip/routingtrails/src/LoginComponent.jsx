import React, { Component } from 'react'
export default class LoginComponent extends React.Component {



    constructor() {
        super()

        this.state = {
            username: '',
            password: ''
        }
    }


    changeHandler = event => {
        console.log(event.target.name)
        console.log(event.target.value)
        this.setState(
            { [event.target.name]: event.target.value }
        )
    }
    submitHandlerOne=event=>{
        // console.log(this.event.target.name)
        // event.preventDefault();
        event.preventDefault()
        console.log(this.state)
    }
    render() {
        return (
            <div>
                <h2>
                    LoginModule
            </h2>

                <form onSubmit={this.submitHandlerOne}>
                    <input type="text" placeholder="UserName"  name="username" onChange={this.changeHandler}/><br/>
                    <input type="text" placeholder="password" name="password" onChange={this.changeHandler} /><br/>
                    <button type="submit">Submit</button>
                </form>
            </div>
        )
    }

}