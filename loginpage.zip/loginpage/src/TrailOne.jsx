import React,{Component} from 'react';
import { METHODS } from 'http';
export default class TrailOne extends React.Component{

constructor(){
super()

this.state={
    name:'',
    mobile:''
}
}
handlerSubmit(event){
    event.preventDefault();
    console.log(event.target.name.value)
}

handlerChange(event){
event.preventDefault();
console.log(":...",event.target.value)
this.setState({name:event.target.value})
}
   render(){
        return(
        <form onSubmit={this.handlerSubmit}>
            <input type='text' name='name' placeholder="Enter Name" value={this.state.name.value} onChange={(item)=>this.handlerChange(item)}></input><br></br>
            <input type='text' name='mobile' placeholder="Enter Mobile" value={this.state.mobile.value} onChange={(sam)=>this.handlerChange(sam)}></input><br></br>
            <button>Submit</button>
        </form>
        )
    }
}