
import React ,{Component} from 'react'
export default class FormSignin extends React.Component{
    
constructor(props){
    super(props)

    this.state={
        name:'',
        password:''
    }
}
  

handleSubmit(event){
    event.preventDefault();
    // this.setState({name:event.target.name.value,password:event.target.password.value});

    // this.setState({password:'hello'})
console.log('finalSubmittion...',event.target.name.value)
console.log('finalSubmittion...',event.target.password.value)
}

handleChange(event){
    event.preventDefault();
    console.log(event.target.value)
}
render(){
    return(
        <form onSubmit={this.handleSubmit}>
        <div>
        <h1>LoginPage</h1>
        <input type='text' placeholder='Enter Name' id='name' value={this.state.name.value} onChange={this.handleChange}/>
        <br/>
        <input type='text' placeholder='Enter Password' name='password' value={this.state.password.value} onChange={this.handleChange}></input>
        <br/>
        <button>submit</button>
        <button type='reset'>clear</button>
        </div>
        </form>
    )
}
}
