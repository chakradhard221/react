import React, { Component } from 'react';
export default class FormTrail2 extends React.Component {


    constructor(props) {
        super(props)
        this.state = {
            name: '',
            number: '',
            class:'',
            pin:'',
            city:''
        }
    }
    changeHandler = event => {
        event.preventDefault();
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    submitHandler = event => {
        event.preventDefault();
     
        console.log(this.state)

        

        fetch("http://localhost:5002/list").then(response=>response.json()).then(responseParsed=>responseParsed.results.map(list=>(
            console.log(list[0])
        )))
    }

    render() {
        return (
            <form onSubmit={this.submitHandler}>
                <label>Enter Name</label>
                <input type="text" name="name" value={this.state.name} onChange={this.changeHandler} />
                <br />
                <label>Enter Number</label>
                <input type="text" name="number" value={this.state.number} onChange={this.changeHandler} />
                <br />
                <label>Class</label>
                <input type="text" name="class" value={this.state.class} onChange={this.changeHandler} />
                <br />
                <label>city</label>
                <input type="text" name="city" value={this.state.city} onChange={this.changeHandler} />
                <br />
                <label>pin</label>
                <input type="text" name="pin" value={this.state.pin1} onChange={this.changeHandler} />
                <br />
                <button type="submit">Submit</button>
            </form>
        )
    }

}