import React,{Component} from 'react'
import { stat } from 'fs'
export default class FormTrail extends React.Component{
constructor(props){
    super(props)
    this.state={
       username:'',
       password:''
    }
}
submitHandler=event=>{
 event.preventDefault();
console.log(this.state)
}
changeHandler(event){
     event.preventDefault();
    console.log(".....evtname...",event.target.name)
    console.log(".....evtvalue..",event.target.value)
    this.setState({
        [event.target.name]:event.target.value
    })
}
render(){
    return(
        <form onSubmit={this.submitHandler}>
            <input type="text" name="username" value={this.state.name} onChange={event=>this.changeHandler(event)}/>
        <br/>
          <input type="text" name="password" value={this.state.password} onChange={event=>this.changeHandler(event)}/>
        <br/>
             <button type="submit">Submit</button>
         </form>
    )
}
}