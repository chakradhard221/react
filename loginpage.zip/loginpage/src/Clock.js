import React,{Component} from 'react';

export default class Clock extends React.Component{
    
    constructor(){

        super()
this.lunchClock();
        this.state={
            currentTime:(new Date()).toLocaleTimeString()
        }
        
    }

    lunchClock(){
        setInterval(()=>{
            this.setState({currentTime:(new Date()).toLocaleTimeString()})
        },1000);
    }
    render(){
        console.log('rendering..clock..')
        return <div>{this.state.currentTime}</div>;
    }
}

