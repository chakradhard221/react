import React from 'react';
import './App.css';
// import FormSignin from './FormSignin'
// import Clock from './Clock'
// import TrailOne from './TrailOne'
// import TrailThree from './TrailThree'
// import FormTrail from './FormTrail'
import FormTrail2 from './FormTrail2'
function App() {
  return (
    // <FormSignin/>
    // <Clock/>
    // <TrailOne></TrailOne>
    // <TrailTwo></TrailTwo>
    // <TrailThree></TrailThree>
    // <FormTrail></FormTrail>
    <FormTrail2></FormTrail2>
  );
}

export default App;
