import React ,{Component} from 'react'
export default class Rendering extends React.Component{

    render(){

        return(

            <h1>HelloReact</h1>
        )
    }

}
const app=document.getElementById('app');
ReactDOM.render(<Rendering></Rendering>,app)
// var const=document.getElementById('app')