import React, { Component } from 'react'

export default class TrailThree extends React.Component {
    constructor() {
        super()
        this.state = {
            name: '',
            mobile: '',
            city: ''
        }
    }

    changeHandler(event) {
        event.preventDefault();
        console.log(event)
    }

    submitHandler(event) {
        event.preventDefault();
        console.log(event)
    }

    render() {
        return (
            <form onSubmit={this.submitHandler}>
                <div>
                    <input type="text" placeholder="Enter Name" id="name" name="name" />
                    <br />
                    {/* <input type="text"  placeholder="Enter Mobile Number"id="mobileNumber" value={this.state.mobile} onChange={(item)=>this.changeHandler} ></input> */}
                    <br />
                    <input type="text" placeholder="Enter City" id="city" name="name" ></input>
                </div>
                <button type="submit">Submit</button>

            </form>
        )
    }

}