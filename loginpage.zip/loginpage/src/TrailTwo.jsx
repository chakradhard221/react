import React,{Component} from 'react'
export default class TrailTwo extends React.Component{


    constructor(){
        super()

        this.state={
            namesList:''
        }
    }

    componentDidMount(){

        fetch('http://localhost:5002/list').then((res)=>res.json()).then(result=>{
            this.setState({
                namesList:result
            })
        })
    }


    render(){
        return this.state.namesList;
    }
}
