export default function(){
    return(
        <div>
            <h2>HomePage</h2>
        </div>
    )
}