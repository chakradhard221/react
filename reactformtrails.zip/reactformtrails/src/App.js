import React from 'react';

import Form from './Form';

function App() {
  return (
    <div className="App">
     <Form></Form>
    </div>
  );
}

export default App;
