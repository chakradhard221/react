import React,{Component} from 'react';
export default class Form extends React.Component{


    constructor(){
        super() 
        this.state={
            "password":'',
            "userName":'',
            "rootUser":''
        }
    }
    submitHandler=event=>{
        event.preventDefault();
        console.log("....submitted..."+this.state.rootUser)
    }
    changeHandler=event=>{
        event.preventDefault();
        console.log("......"+event)

        this.setState({
            [event.target.name]:event.target.value
        })

        
    }


    dataHandler(){
        console.log("...stateValue..."+this.state.password)
    }
    render(){
        return(
            <div>
                <form onSubmit={this.submitHandler}>
                    <div>
                        <input type="text" name="password" placeholder="EnterPassword" onChange={this.changeHandler}></input>

                    </div>
                    <button type="submit">submit</button>
                    <button onClick={this.dataHandler}>getData</button>
                </form>
            </div>
        )
    }

}